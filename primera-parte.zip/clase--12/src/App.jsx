import './App.css';
import TecnicaUno from './componentes/TecnicaUno/TecnicaUno';
import TecnicaDos from './componentes/TecnicaDos/TecnicaDos';
import TecnicaTres from './componentes/TecnicaTres/TecnicaTres';
import EstilosCondicional from './componentes/EstilosCondicional/EstilosCondicional';
import BotonCondicional from './componentes/BotonCondicional/BotonCondicional';

function App() {
  return (
    <div className="App">
        <TecnicaUno nombre={"Samuel"}/>
        <TecnicaDos booleano={true} />
        <TecnicaTres booleano={false} />
        <EstilosCondicional booleano={true}  clase={"nuevaClase"}/>
        <BotonCondicional />
    </div>
  );
}

export default App;

//Técnicas de Renderizado: 

//1) Renderizado condicional: mostramos componentes en función de una condición o estado determinado en tiepo de ejecución. 

//Por ejemplo: mostra un botón si el usuario esta logueado. 
